var main = function() {

	var viewport = $(window).width();
	console.log(viewport);

	if (viewport < 800) {
		$('.social-media').removeClass('five columns'); // change the Skeleton class
		$('.contact').removeClass('five columns');
	}

	// 	$('.tag').addClass('ten');
	// 	$('.pull').removeClass('hidden'); // set the menu icon to be shown
	// 	$('.menu').hide();//.addClass('hidden'); // hide the menu
	// 	$('.menu').addClass('mob-menu');
	// 	$('.mob-menu').removeClass('menu'); //
	// 	// onClick();
	// } else {
	// 	$('nav').removeClass('two'); // change the Skeleton class
	// 	$('nav').addClass('six');
	// 	$('.tag').removeClass('ten');
	// 	$('.tag').addClass('six');
	// 	$('.pull').addClass('hidden'); // set the menu icon to be shown
	// 	$('.mob-menu').addClass('menu');
	// 	$('.menu').removeClass('mob-menu');
	// 	$('.menu').show();//.addClass('hidden'); // hide the menu
	// }


// .addClass('active')
}

// function onClick() {
// 		console.log(menuopen);
// 	if (menuopen) {
// 		$('.mob-menu').hide();//.removeClass('hidden');
// 		menuopen = false;
// 	} else {
// 		$('.mob-menu').show();//.removeClass('hidden');
// 		menuopen = true;
// 	}
// }

$ (document).ready(function(){
	// $('.pull').click(onClick); // passing the function onClick. onClick() would be calling and passing return value
	main();
});

$(window).resize(main);