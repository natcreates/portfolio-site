

<?php get_header(); ?>  

  <div class="container">
    <div class="row">
      <section>
          <div class="ten columns offset-by-one column summary">
           <img class ="homepage" src="<?php echo get_template_directory_uri(); ?>/img/homeicon.jpeg" alt="designing illustration">
           <div class="headline">
            <h2>Natalie Dixon</h2>
            <h1><span class="designer">Web Designer</span> <br>& FRONT-END DEVELOPER</h1>
            <h3 class="strapline">Crafts code, doesn't talk in it.</h3>
          </div>
        </div>
      </section>
    </div><!--end row-->
    <div class="row">
       <div class="twelve columns intro">
          <p>I'm a London-based web designer, developer and writer. I see projects in the context of larger content strategies—leading to sharp, targeted sites that provide clear calls-to-action. I craft code, but don't talk in it! </p>
          <p class="calltoaction">Let's give your ideas a voice and a platform. <a href="#contact">Hire me.</a></p>
        </div>
    </div><!--end row-->
    <div class="row">
      <div class="eight columns">
         <blockquote>As a small business we wanted a website that would be beautiful, easy-to-use and express who we were. Natalie made this happen for us. We are so happy!!<cite>--Amber Cassidy, <a href="http://www.barneysbubble.com">www.barneysbubble.com</a></cite></blockquote>
      </div>
      <div class="four columns">
         <p class="download">In a rush? I get it. <a href="<?php echo get_template_directory_uri(); ?>/files/NatalieDixon_CV_2015WEB.pdf" target="_blank">Download my CV.</a></p>
      </div>
    </div>

    <hr>
    <div class="row">
      <h2>SKILLS</h2>
      <a id="skills"></a>
      <section class="skills twelve columns">

      <div class="skill-detail four columns">
          <a id="web"></a>
          <span class="fa-stack fa-2x">
                <i class="fa fa-circle fa-stack-2x"></i>
               <i class="fa fa-code fa-stack-1x"></i>
              </span>
          <h3>CODE</h3>
          <p>I build responsive, device-agnostic websites that make sense to visitors, search engines and you. Because I build over content management systems like WordPress, you'll find updating your site a breeze. I can breathe life into an existing design, or work with you to create one that's aligned with your brand and your customers' needs.</p>
          <ul>
            <li class="skill">HTML5</li>
            <li class="skill">CSS3</li>
            <li class="skill">WordPress</li>
          </ul>
        </div>

        <div class="skill-detail four columns">
          <a id="content"></a>
          <span class="fa-stack fa-2x">
                <i class="fa fa-circle fa-stack-2x"></i>
               <i class="fa fa-pencil fa-stack-1x"></i>
              </span>
          <h3>CONTENT</h3>
          <p>With several roles in publishing editorial and communications behind me, I know how to make a message clear, consistent and accurate. I've crafted compelling copy for insurance companies, homestay businesses and financial publishers. I'm used to coordinating difficult projects. Working with me is a jargon-free experience.</p>
          <ul>
            <li class="skill">Writing</li>
            <li class="skill">Editing</li>
            <li class="skill">Proofing</li>
          </ul>
        </div>

        <div class="skill-detail four columns">
          <a id="graphics"></a>
          <span class="fa-stack fa-2x">
                <i class="fa fa-circle fa-stack-2x"></i>
               <i class="fa fa-paint-brush fa-stack-1x"></i>
              </span>
          <h3>GRAPHICS</h3>
          <p>I have extensive experience with Photoshop, Illustrator and InDesign, which means I can create everything from painterly artwork to scaleable vector graphics and sophisticated page layouts. I've worked both in-house and as a freelancer, designing eye-catching adverts, posters, logos, sponsorship proposals and marketing materials. </p>
          <ul>
            <li class="skill">Photoshop</li>
            <li class="skill">Illustrator</li>
            <li class="skill">InDesign</li>
          </ul>
        </div>

      </section>
    </div><!--end row-->
    

  
    <hr>
    </div><!--end container-->
      <a id="work"></a>
         <h2>WORK</h2>

      <?php echo do_shortcode('[ngg_images gallery_ids="1" display_type="photocrati-nextgen_basic_thumbnails"]'); ?>
    

    <div class="container">

    <hr>

    <section class="contact-details">
      <div class="row">
        <div class="twelve columns">
          <h2>CONTACT</h2>
          <p>Intrigued? Get in touch!</p>
          <a name="contact"></a>
        </div><!--end twelve columns-->
      </div><!--end row-->

        <div class="row">
          <div class="six columns">
              <a href="tel:00447548282074">
                <span class="fa-stack fa-2x">
                      <i class="fa fa-circle fa-stack-2x"></i>
                      <i class="fa fa-phone fa-stack-1x"></i>
                </span>
                <p>+447548282074</p>
             </a>
          </div><!--end six columns-->
          
          <div class="six columns">
            <a href="mailto:natalie@nataliejdixon.com">
              <span class="fa-stack fa-2x">
                    <i class="fa fa-circle fa-stack-2x"></i>
                    <i class="fa fa-envelope fa-stack-1x"></i>
              </span>
              <p>natalie@nataliejdixon.com</p>
            </a>
          </div><!--end six columns-->
        </div><!--end row-->
      </section><!--end section-->

  </div><!--end container-->

<?php get_footer(); ?>  <!--Wordpress PHP function-->