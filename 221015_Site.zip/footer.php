 <footer>
	<div class="container">
	 <div class="row">
    <div class="contact five columns">
      <a href="tel:00447548282074">
        <span class="fa-stack fa-1x">
            <i class="fa fa-circle fa-stack-2x"></i>
            <i class="fa fa-phone fa-stack-1x"></i>
        </span>
        <p>+447548282074</p>
      </a>
        
      <a href="mailto:natalie@nataliejdixon.com">
        <span class="fa-stack fa-1x">
          <i class="fa fa-circle fa-stack-2x"></i>
          <i class="fa fa-envelope fa-stack-1x"></i>
        </span>
        <p>natalie@nataliejdixon.com</p>
      </a>
    </div><!--end contact-->

    <p class="">&copy; Natalie Dixon 2015</p>

    <div class="social-media five columns">
      <p class="feeling-social">Feeling social?</p>
      <a href="https://twitter.com/natcreates">
        <span class="fa-stack fa-1x">
          <i class="fa fa-circle fa-stack-2x"></i>
          <i class="fa fa-twitter fa-stack-1x"></i>
        </span>
      </a>

      <a href="https://uk.linkedin.com/in/nataliejdixon">
        <span class="fa-stack fa-1x">
          <i class="fa fa-circle fa-stack-2x"></i>
          <i class="fa fa-linkedin fa-stack-1x"></i>
        </span>
      </a>
    </div><!--end social-media-->
  </div><!--end row-->
</div><!--end container-->

</footer>

<?php wp_footer(); ?> <!-- //Wordpress function to allow admin drop-down -->
<!-- End Document
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
</body>
</html>